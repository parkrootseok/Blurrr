drop table if exists alarms;

drop table if exists cars;

drop table if exists channel_board;

drop table if exists channel_member_follow;

drop table if exists channel_tag;

drop table if exists comments;

drop table if exists league_board;

drop table if exists league_member;

drop table if exists likes;

drop table if exists mentions;

drop table if exists leagues;

drop table if exists my_car_board;

drop table if exists tags;

drop table if exists videos;

drop table if exists votes;

drop table if exists options;

drop table if exists dashcams;

drop table if exists boards;

drop table if exists channels;

drop table if exists members;

create table cars
(
    idx          int auto_increment comment 'Primary Key'
        primary key,
    brand        varchar(255)  null,
    series       varchar(255)  null,
    model_detail varchar(1000) null
);

create table leagues
(
    id           binary(16)                  not null
        primary key,
    created_at   datetime(6)                 null,
    status       enum ('ACTIVE', 'INACTIVE') null,
    updated_at   datetime(6)                 null,
    name         varchar(255)                not null,
    people_count bigint                      not null,
    type         enum ('BRAND', 'MODEL')     null,
    constraint UKip3mfd1fg0kl2jqep6fvp76ly
        unique (name)
);

create table members
(
    id              binary(16)                                               not null
        primary key,
    created_at      datetime(6)                                              null,
    status          enum ('ACTIVE', 'INACTIVE')                              null,
    updated_at      datetime(6)                                              null,
    car_manufacture varchar(255)                                             null,
    car_mode        varchar(255)                                             null,
    car_show        bit                                                      not null,
    car_title       varchar(255)                                             null,
    email           varchar(255)                                             not null,
    is_auth         bit                                                      null,
    nickname        varchar(20)                                              not null,
    password        varchar(255)                                             not null,
    profile_url     varchar(255)                                             not null,
    role            enum ('ROLE_ADMIN', 'ROLE_AUTH_USER', 'ROLE_BASIC_USER') null,
    constraint uniqueEmail
        unique (email),
    constraint uniqueNickname
        unique (nickname)
);

create table alarms
(
    id         binary(16)                             not null
        primary key,
    created_at datetime(6)                            null,
    status     enum ('ACTIVE', 'INACTIVE')            null,
    updated_at datetime(6)                            null,
    alarm_type enum ('ADD_COMMENT', 'ADD_RE_COMMENT') null,
    is_read    bit                                    not null,
    link       varchar(255)                           null,
    message    varchar(255)                           null,
    title      varchar(255)                           not null,
    member_id  binary(16)                             null,
    constraint FKeimg6kf46ans5qbduutv98s82
        foreign key (member_id) references members (id)
);

create table boards
(
    dtype         varchar(31)                                    not null,
    id            binary(16)                                     not null
        primary key,
    created_at    datetime(6)                                    null,
    status        enum ('ACTIVE', 'INACTIVE')                    null,
    updated_at    datetime(6)                                    null,
    comment_count bigint                                         not null,
    content       text                                           not null,
    like_count    bigint                                         not null,
    title         varchar(30)                                    not null,
    type          enum ('CHANNEL', 'DASHCAM', 'LEAGUE', 'MYCAR') not null,
    view_count    bigint                                         not null,
    member_id     binary(16)                                     not null,
    constraint FK4cax2c8dmo1vix11xy3h3qojb
        foreign key (member_id) references members (id)
);

create table channels
(
    id           binary(16)                  not null
        primary key,
    created_at   datetime(6)                 null,
    status       enum ('ACTIVE', 'INACTIVE') null,
    updated_at   datetime(6)                 null,
    follow_count bigint                      not null,
    img_url      varchar(256)                not null,
    info         varchar(50)                 not null,
    name         varchar(20)                 not null,
    owner_id     binary(16)                  null,
    constraint UKlw4k451ty7vjo4s9j5gh20imm
        unique (name),
    constraint FKqpwidcxdsc6a5adymqkhu55m5
        foreign key (owner_id) references members (id)
);

create table channel_board
(
    id         binary(16) not null
        primary key,
    channel_id binary(16) null,
    constraint FKh0bsxiafenobs42m07y1rs3fy
        foreign key (channel_id) references channels (id),
    constraint FKjonl20imhpwmuwjshoblyna7d
        foreign key (id) references boards (id)
);

create table channel_member_follow
(
    id         bigint auto_increment
        primary key,
    channel_id binary(16) null,
    member_id  binary(16) null,
    constraint uniqueMemberChannel
        unique (member_id, channel_id),
    constraint FKllxpi512h9ehtnqinmgt0fls6
        foreign key (channel_id) references channels (id),
    constraint FKr2wg3yo87tcxyt88wprxdpemn
        foreign key (member_id) references members (id)
);

create table comments
(
    id         binary(16)                  not null
        primary key,
    created_at datetime(6)                 null,
    status     enum ('ACTIVE', 'INACTIVE') null,
    updated_at datetime(6)                 null,
    content    text                        not null,
    type       enum ('COMMENT', 'REPLY')   null,
    board_id   binary(16)                  not null,
    comment_id binary(16)                  null,
    member_id  binary(16)                  not null,
    constraint FKe2dbs56lhmp8fucafi3xvhjyd
        foreign key (comment_id) references comments (id),
    constraint FKkv22t54g17a6hvj7hbn6byh5s
        foreign key (member_id) references members (id),
    constraint FKo7l08y12wlmjbt81ey5wysk2g
        foreign key (board_id) references boards (id)
);

create table dashcams
(
    thumb_nail       varchar(255) null,
    total_vote_count bigint       not null,
    vote_title       varchar(35)  null,
    id               binary(16)   not null
        primary key,
    channel_id       binary(16)   null,
    thumbnail        varchar(255) null,
    constraint FK1xd9482u4aa0bvf2563suen9c
        foreign key (channel_id) references channels (id),
    constraint FK751elrc0t4nmena4mgthrvjo8
        foreign key (id) references boards (id)
);

create table league_board
(
    id        binary(16) not null
        primary key,
    league_id binary(16) null,
    constraint FK3pck913mn41lbksflqwjyrdfb
        foreign key (id) references boards (id),
    constraint FK9jya517g84ujoa6k03f7mi99a
        foreign key (league_id) references leagues (id)
);

create table league_member
(
    id        bigint auto_increment
        primary key,
    league_id binary(16) not null,
    member_id binary(16) not null,
    constraint FK2dly1qejvw5ep95vr223cr0s3
        foreign key (league_id) references leagues (id),
    constraint FKf3qu5fubyoujjxje5lv2tgtuc
        foreign key (member_id) references members (id)
);

create table likes
(
    id        bigint auto_increment
        primary key,
    board_id  binary(16) null,
    member_id binary(16) null,
    constraint uniqueMemberBoard
        unique (member_id, board_id),
    constraint FK166rh7nhmtcajf0xo1f1i3s8p
        foreign key (member_id) references members (id),
    constraint FKkr7j7p7tbklbqsjn73kv3xeb2
        foreign key (board_id) references boards (id)
);

create table mentions
(
    id        bigint auto_increment
        primary key,
    board_id  binary(16) null,
    league_id binary(16) null,
    constraint FK4fiob4gxgmxhvsoyb2gpdeq1
        foreign key (board_id) references boards (id),
    constraint FK73lowt6npi3vhl7ullm55aofc
        foreign key (league_id) references leagues (id)
);

create table my_car_board
(
    thumbnail  text       not null,
    id         binary(16) not null
        primary key,
    channel_id binary(16) null,
    constraint FK5aat3igc57xs37rmyil9kqqq4
        foreign key (channel_id) references channels (id),
    constraint FKb3qrbm3s2j8uewd8txhtkr4y0
        foreign key (id) references boards (id)
);

create table options
(
    id           binary(16)                  not null
        primary key,
    created_at   datetime(6)                 null,
    status       enum ('ACTIVE', 'INACTIVE') null,
    updated_at   datetime(6)                 null,
    content      varchar(200)                null,
    option_order int                         not null,
    vote_count   bigint                      null,
    dashcam_id   binary(16)                  not null,
    constraint FKc8kaanv4qb5shlf9kikd6xmre
        foreign key (dashcam_id) references dashcams (id)
);

create table tags
(
    id         binary(16)                  not null
        primary key,
    created_at datetime(6)                 null,
    status     enum ('ACTIVE', 'INACTIVE') null,
    updated_at datetime(6)                 null,
    name       varchar(20)                 not null,
    constraint UKt48xdq560gs3gap9g7jg36kgc
        unique (name)
);

create table channel_tag
(
    id         bigint auto_increment
        primary key,
    channel_id binary(16) null,
    tag_id     binary(16) null,
    constraint FKikp4pduslcc7c0jlv5iydxisa
        foreign key (channel_id) references channels (id),
    constraint FKrrv08qxv30a7696p1n1hcuk8t
        foreign key (tag_id) references tags (id)
);

create table videos
(
    id          binary(16)                  not null
        primary key,
    created_at  datetime(6)                 null,
    status      enum ('ACTIVE', 'INACTIVE') null,
    updated_at  datetime(6)                 null,
    video_order int                         not null,
    url         varchar(512)                null,
    dashcam_id  binary(16)                  not null,
    constraint FK38qu7yxmf8tpn9e6oel48jb8b
        foreign key (dashcam_id) references dashcams (id)
);

create table votes
(
    id         binary(16)                  not null
        primary key,
    created_at datetime(6)                 null,
    status     enum ('ACTIVE', 'INACTIVE') null,
    updated_at datetime(6)                 null,
    dashcam_id binary(16)                  null,
    member_id  binary(16)                  null,
    option_id  binary(16)                  not null,
    constraint FK6jvn8q2q9mp6lgutfjw15dww6
        foreign key (member_id) references members (id),
    constraint FKbbao3pl0lh5gakk0vr2xy3whw
        foreign key (dashcam_id) references dashcams (id),
    constraint FKegm12kr5toym1nt7ndgr9isw9
        foreign key (option_id) references options (id)
);

